export const SUPPORTED_FORMATS = ["image/png", "image/jpg", "image/jpeg"];
export const ACCEPTED_MEDIA_TYPES = "image/png,image/jpg,image/jpeg";
export const FILE_SIZE = 4000;
