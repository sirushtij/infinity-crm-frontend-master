export const types = {
  create: "create",
  read: "read",
  edit: "edit",
  delete: "delete",
};
