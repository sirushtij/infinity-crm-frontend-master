export const permissions = {
  enquiry: "enquiry",
  sales_lead: "sales_lead",
  receipt: "receipt",
};
export const scopes = {
  read: "read",
  create: "create",
  edit: "edit",
  delete: "delete",
};
